﻿namespace L1.Avalonia.Gif.Decoding;

public class GifRepeatBehavior
{
    public bool LoopForever { get; set; }
    public int? Count { get; set; }
}
