namespace L1.Avalonia.Gif.Decoding;

internal enum ExtensionType
{
    GRAPHICS_CONTROL = 0xF9,
    APPLICATION = 0xFF
}
