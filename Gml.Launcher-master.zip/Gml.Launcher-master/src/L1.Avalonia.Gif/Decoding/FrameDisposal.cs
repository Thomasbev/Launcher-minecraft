namespace L1.Avalonia.Gif.Decoding;

public enum FrameDisposal
{
    Unknown = 0,
    Leave = 1,
    Background = 2,
    Restore = 3
}
