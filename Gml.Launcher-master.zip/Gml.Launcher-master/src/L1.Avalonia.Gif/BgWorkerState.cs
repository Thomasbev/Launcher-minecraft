﻿namespace L1.Avalonia.Gif;

internal enum BgWorkerState
{
    Null,
    Start,
    Running,
    Paused,
    Complete,
    Dispose
}
