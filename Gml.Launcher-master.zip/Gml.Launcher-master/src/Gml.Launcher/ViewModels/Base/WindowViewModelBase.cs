﻿namespace Gml.Launcher.ViewModels.Base;

public class WindowViewModelBase : ViewModelBase
{
}
