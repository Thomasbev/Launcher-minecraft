﻿using Avalonia.Controls;

namespace Gml.Launcher.Views.Components;

public partial class ServerListComponent : UserControl
{
    public ServerListComponent()
    {
        InitializeComponent();
    }
}
