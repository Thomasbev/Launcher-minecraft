namespace Gml.Launcher.Core.Services;

public interface IVpnChecker
{
    bool IsUseVpnTunnel();
}
